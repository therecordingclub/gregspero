
import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

const DATA_FILE = path.join(process.cwd(), 'src/data/emails.json');

export async function POST(request: Request) {
    try {
        const { email } = await request.json();

        if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
            return NextResponse.json({ error: 'Invalid email address' }, { status: 400 });
        }

        // Ensure data directory exists
        const dir = path.dirname(DATA_FILE);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }

        let emails: string[] = [];
        if (fs.existsSync(DATA_FILE)) {
            const fileContent = fs.readFileSync(DATA_FILE, 'utf-8');
            try {
                emails = JSON.parse(fileContent);
            } catch (e) {
                console.error("Error parsing emails JSON:", e);
                emails = [];
            }
        }

        if (!emails.includes(email)) {
            emails.push(email);
            fs.writeFileSync(DATA_FILE, JSON.stringify(emails, null, 2));
        }

        return NextResponse.json({ success: true, message: 'Subscribed successfully!' });
    } catch (error) {
        console.error('Subscription error:', error);
        return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
    }
}
