
import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

const DATA_FILE = path.join(process.cwd(), 'src/data/emails.json');
// Simple PIN for demonstration. In a real app, use environment variables.
const ADMIN_PIN = "1234";

export async function POST(request: Request) {
    try {
        const { pin } = await request.json();

        if (pin !== ADMIN_PIN) {
            return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
        }

        let emails: string[] = [];
        if (fs.existsSync(DATA_FILE)) {
            const fileContent = fs.readFileSync(DATA_FILE, 'utf-8');
            try {
                emails = JSON.parse(fileContent);
            } catch (e) {
                console.error("Error parsing emails JSON:", e);
                emails = [];
            }
        }

        return NextResponse.json({ emails });
    } catch (error) {
        console.error('Admin error:', error);
        return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
    }
}
