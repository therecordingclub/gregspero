import Navbar from '../components/Navbar';
import Hero from '../components/Hero';
import Bio from '../components/Bio';
import Projects from '../components/Projects';
import Contact from '../components/Contact';
import Newsletter from '../components/Newsletter';

export default function Home() {
  return (
    <main>
      <Navbar />
      <Hero />
      <Bio />
      <Projects />
      <Contact />
      <Newsletter />
      <footer style={{ padding: '2rem', textAlign: 'center', color: '#666', fontSize: '0.8rem' }}>
        &copy; {new Date().getFullYear()} Greg Spero. All rights reserved.
      </footer>
    </main>
  );
}
