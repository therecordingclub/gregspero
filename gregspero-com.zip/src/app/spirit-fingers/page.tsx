import Image from 'next/image';
import styles from './style.module.css';
import Link from 'next/link';

export const metadata = {
    title: 'Spirit Fingers | Greg Spero',
    description: 'The official landing page for Spirit Fingers, led by pianist Greg Spero.',
};

export default function SpiritFingersPage() {
    return (
        <div className={styles.container}>
            <video
                autoPlay
                muted
                loop
                playsInline
                className={styles.videoBackground}
                poster="/spirit-fingers/peace-album.jpg" // Fallback
            >
                <source src="/spirit-fingers/background.mp4" type="video/mp4" />
                Your browser does not support the video tag.
            </video>

            <div className={styles.content}>
                {/* Neon Logo */}
                <div className={styles.logoWrapper}>
                    <Image
                        src="/spirit-fingers/neon-logo.png"
                        alt="Spirit Fingers Neon Logo"
                        width={953}
                        height={239}
                        className={styles.logo}
                        priority
                    />
                </div>

                {/* Album Art (Optional, can replace or sit below logo if desired, or maybe just CTA) 
            Design choice: Keeps it simple like the Splash page usually is. 
            I'll include it for now as it was requested/downloaded.
        */}
                {/* <Image
          src="/spirit-fingers/peace-album.jpg"
          alt="Peace Album Art"
          width={500}
          height={500}
          className={styles.albumArt}
        /> */}

                {/* CTA */}
                <a href="https://open.spotify.com/artist/2vVjFwWd2Q4Q4Q4Q4Q4Q4Q" target="_blank" rel="noopener noreferrer" className={styles.ctaButton}>
                    Listen to PEACƎ
                </a>

                {/* Navigation */}
                <nav className={styles.socialNav}>
                    <Link href="/" className={styles.socialLink}>
                        Home
                    </Link>
                    <Link href="/#bio" className={styles.socialLink}>Bio</Link>
                    <a href="https://www.bandsintown.com/a/193264-greg-spero" target="_blank" rel="noopener noreferrer" className={styles.socialLink}>Tour</a>
                    <a href="https://www.youtube.com/c/GregSpero" target="_blank" rel="noopener noreferrer" className={styles.socialLink}>Videos</a>
                    <a href="https://gregspero.bandcamp.com/merch" target="_blank" rel="noopener noreferrer" className={styles.socialLink}>Store</a>
                </nav>
            </div>
        </div>
    );
}
