
'use client';

import React, { useState } from 'react';

export default function AdminPage() {
    const [pin, setPin] = useState('');
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [emails, setEmails] = useState<string[]>([]);
    const [error, setError] = useState('');

    const handleLogin = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');

        try {
            const res = await fetch('/api/admin', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ pin }),
            });

            const data = await res.json();

            if (res.ok) {
                setIsAuthenticated(true);
                setEmails(data.emails);
            } else {
                setError('Invalid PIN');
            }
        } catch (err) {
            setError('Login failed');
        }
    };

    const copyToClipboard = () => {
        navigator.clipboard.writeText(emails.join(', '));
        alert('Copied to clipboard!');
    };

    if (!isAuthenticated) {
        return (
            <div style={styles.container}>
                <h1 style={styles.heading}>Admin Access</h1>
                <form onSubmit={handleLogin} style={styles.form}>
                    <input
                        type="password"
                        placeholder="Enter PIN"
                        value={pin}
                        onChange={(e) => setPin(e.target.value)}
                        style={styles.input}
                    />
                    <button type="submit" style={styles.button}>Login</button>
                </form>
                {error && <p style={styles.error}>{error}</p>}
            </div>
        );
    }

    return (
        <div style={styles.container}>
            <div style={styles.header}>
                <h1 style={styles.heading}>Mailing List ({emails.length})</h1>
                <button onClick={copyToClipboard} style={styles.outlineButton}>Copy All</button>
            </div>

            <div style={styles.list}>
                {emails.length === 0 ? (
                    <p style={styles.empty}>No subscribers yet.</p>
                ) : (
                    emails.map((email, i) => (
                        <div key={i} style={styles.item}>
                            {email}
                        </div>
                    ))
                )}
            </div>
        </div>
    );
}

const styles = {
    container: {
        minHeight: '100vh',
        padding: '4rem 2rem',
        backgroundColor: '#050505',
        color: '#fff',
        display: 'flex',
        flexDirection: 'column' as const,
        alignItems: 'center',
    },
    heading: {
        fontSize: '2rem',
        marginBottom: '2rem',
        fontWeight: 300,
    },
    form: {
        display: 'flex',
        gap: '0.5rem',
    },
    input: {
        padding: '0.8rem',
        borderRadius: '4px',
        border: '1px solid #333',
        backgroundColor: '#111',
        color: '#fff',
        fontSize: '1rem',
    },
    button: {
        padding: '0.8rem 1.5rem',
        borderRadius: '4px',
        border: 'none',
        backgroundColor: '#fff',
        color: '#000',
        cursor: 'pointer',
        fontSize: '1rem',
    },
    outlineButton: {
        padding: '0.5rem 1rem',
        borderRadius: '4px',
        border: '1px solid #fff',
        backgroundColor: 'transparent',
        color: '#fff',
        cursor: 'pointer',
        fontSize: '0.9rem',
    },
    error: {
        color: '#ff6b6b',
        marginTop: '1rem',
    },
    header: {
        display: 'flex',
        justifyContent: 'space-between',
        width: '100%',
        maxWidth: '600px',
        alignItems: 'center',
        marginBottom: '2rem',
    },
    list: {
        width: '100%',
        maxWidth: '600px',
        backgroundColor: '#111',
        borderRadius: '8px',
        overflow: 'hidden',
    },
    item: {
        padding: '1rem',
        borderBottom: '1px solid #222',
    },
    empty: {
        padding: '2rem',
        textAlign: 'center' as const,
        color: '#666',
    }
};
