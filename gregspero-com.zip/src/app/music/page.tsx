import Image from 'next/image';
import Link from 'next/link';
import styles from './style.module.css';
import Navbar from '../../components/Navbar';

export const metadata = {
    title: 'Music | Greg Spero',
    description: 'The musical career of Greg Spero: Spirit Fingers, Halsey, Miles Electric Band, and The Recording Club.',
};

export default function MusicPage() {
    return (
        <div className={styles.container}>
            <Navbar />

            {/* Hero */}
            <header className={styles.hero}>
                <h1 className={styles.heroTitle}>Music</h1>
                <p className={styles.heroSubtitle}>Pianist • Composer • Producer</p>
            </header>

            {/* Spotify Embed */}
            <section className={styles.spotifySection}>
                <div className={styles.spotifyContainer}>
                    <div className={styles.spotifyInfo}>
                        <h2 className={styles.spotifyTitle}>Latest Releases</h2>
                        <p className={styles.spotifyDesc}>
                            Stream the latest tracks from Greg Spero, Spirit Fingers, solo piano works, and collaborations.
                            Included here are the brand new 2025 releases <strong>POP-OLOGY</strong> and <strong>Journeys</strong>.
                        </p>
                    </div>
                    <div className={styles.spotifyEmbedList}>
                        <iframe
                            style={{ borderRadius: '12px' }}
                            src="https://open.spotify.com/embed/album/0gLBOn5Qq3BlzgyzF9SDcJ?utm_source=generator&theme=0"
                            width="100%"
                            height="352"
                            allowFullScreen
                            allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
                            loading="lazy"
                        ></iframe>
                        <iframe
                            style={{ borderRadius: '12px' }}
                            src="https://open.spotify.com/embed/album/3Zb8PNjZy5XU7XRzQXtgbL?utm_source=generator&theme=0"
                            width="100%"
                            height="352"
                            allowFullScreen
                            allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
                            loading="lazy"
                        ></iframe>
                        <iframe
                            style={{ borderRadius: '12px' }}
                            src="https://open.spotify.com/embed/album/6UbOXgzwEvCW12WHDwSqr3?utm_source=generator&theme=0"
                            width="100%"
                            height="352"
                            allowFullScreen
                            allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
                            loading="lazy"
                        ></iframe>
                    </div>
                </div>
            </section>

            {/* Spirit Fingers Feature */}
            <section id="spirit-fingers" className={styles.spiritFingers}>
                <video
                    autoPlay
                    muted
                    loop
                    playsInline
                    className={styles.videoBackground}
                    poster="/spirit-fingers/peace-album.jpg"
                >
                    <source src="/spirit-fingers/background.mp4" type="video/mp4" />
                </video>

                <div className={styles.sfContent}>
                    <Image
                        src="/spirit-fingers/neon-logo.png"
                        alt="Spirit Fingers Neon Logo"
                        width={800}
                        height={200}
                        className={styles.neonLogo}
                        style={{ width: '100%', height: 'auto', maxWidth: '600px' }}
                    />
                    <p style={{ maxWidth: '600px', fontSize: '1.2rem', lineHeight: '1.6', textShadow: '0 2px 4px rgba(0,0,0,0.8)' }}>
                        A jazz-fusion supergroup merging cerebral harmony with visceral rhythm.
                        Featuring Dario Chiazzolino, Hadrien Feraud, and Mike Mitchell.
                    </p>
                    <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', justifyContent: 'center' }}>
                        <a href="https://open.spotify.com/artist/2vVjFwWd2Q4Q4Q4Q4Q4Q4Q" target="_blank" rel="noopener noreferrer" className={styles.ctaButton}>
                            Listen to PEACE
                        </a>
                        <a href="https://www.bandsintown.com/a/319445-greg-spero" target="_blank" rel="noopener noreferrer" className={styles.ctaButton} style={{ background: 'transparent' }}>
                            Tour Dates
                        </a>
                    </div>
                </div>
            </section>

            {/* Collaborations */}
            <section className={styles.section}>
                <h2 className={styles.sectionTitle}>Collaborations</h2>
                <div className={styles.collabGrid}>
                    <div className={styles.collabCard}>
                        <h3 className={styles.collabTitle}>Halsey</h3>
                        <p className={styles.collabDesc}>
                            Served as Halsey's pianist, keyboardist, and sound designer for 4 years (2014-2018).
                            Performed at Madison Square Garden, The Forum, and on SNL, designing the sonic landscape for her live shows.
                        </p>
                    </div>
                    <div className={styles.collabCard}>
                        <h3 className={styles.collabTitle}>Miles Electric Band</h3>
                        <p className={styles.collabDesc}>
                            Touring keyboardist for the official Miles Davis estate project.
                            Performing the electric era music of Miles Davis alongside alumni and modern jazz legends.
                        </p>
                    </div>
                </div>
            </section>

            {/* The Recording Club / Tiny Room */}
            <section className={styles.section}>
                <h2 className={styles.sectionTitle}>The Recording Club</h2>
                <p style={{ color: '#aaa', marginBottom: '2rem', fontSize: '1.1rem' }}>
                    Intimate live sessions from Greg's LA studio, featuring world-class improvisers.
                </p>
                <div className={styles.videoGrid}>

                    {/* The Tip */}
                    <div className={styles.videoWrapper}>
                        <iframe
                            src="https://www.youtube.com/embed/C8m1wyOSPGA"
                            title="Greg Spero - The Tip (Tiny Room Sessions)"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowFullScreen
                        ></iframe>
                    </div>

                    {/* Spirit Fingers - Find */}
                    <div className={styles.videoWrapper}>
                        <iframe
                            src="https://www.youtube.com/embed/T5mtXgN7xGU"
                            title="Spirit Fingers - Find (Tiny Room Live Performance)"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowFullScreen
                        ></iframe>
                    </div>

                    {/* Spirit Fingers - Inside */}
                    <div className={styles.videoWrapper}>
                        <iframe
                            src="https://www.youtube.com/embed/XI2WqE4ZMe8"
                            title="Spirit Fingers - Inside (Tiny Room Sessions)"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowFullScreen
                        ></iframe>
                    </div>

                    {/* Halloween - MonoNeon & Spero */}
                    <div className={styles.videoWrapper}>
                        <iframe
                            src="https://www.youtube.com/embed/8oJNBRhmWJ8"
                            title="Greg Spero & MonoNeon - Halloween"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowFullScreen
                        ></iframe>
                    </div>

                    {/* Spirit Fingers - Lest We Forget */}
                    <div className={styles.videoWrapper}>
                        <iframe
                            src="https://www.youtube.com/embed/6v6qx5o4XKI"
                            title="Spirit Fingers - Lest We Forget"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowFullScreen
                        ></iframe>
                    </div>

                    {/* Spirit Fingers - Maps */}
                    <div className={styles.videoWrapper}>
                        <iframe
                            src="https://www.youtube.com/embed/8VETJzTMz-M"
                            title="Spirit Fingers - Maps"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowFullScreen
                        ></iframe>
                    </div>

                    {/* Ruslan & Spero */}
                    <div className={styles.videoWrapper}>
                        <iframe
                            src="https://www.youtube.com/embed/S6_EMdSs45k"
                            title="Greg Spero & Ruslan Sirota - Live"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowFullScreen
                        ></iframe>
                    </div>
                </div>
                {/* Correction: I'll do a quick search for a real ID first! */}
            </section>
        </div>
    );
}
