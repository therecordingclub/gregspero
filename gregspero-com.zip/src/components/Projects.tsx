import { CSSProperties } from "react";

const projects = [
    {
        category: "Music",
        title: "Spirit Fingers",
        desc: "A jazz-fusion supergroup merging cerebral harmony with visceral rhythm.",
        link: "/music",
    },
    {
        category: "Studio",
        title: "The Recording Club",
        desc: "Los Angeles based hub for high-fidelity live sessions and collaboration.",
        link: "https://therecording.club",
    },
    {
        category: "Technology",
        title: "Artist AI",
        desc: "The world's first AI artist manager. Streamlining logistics to empower pure creativity.",
        link: "https://www.joinartistai.com/",
    }
];

export default function Projects() {
    return (
        <section id="projects" className="section container">
            <h2 style={{ marginBottom: '5rem', paddingLeft: '2rem', fontSize: '1rem', textTransform: 'uppercase', letterSpacing: '0.2em', color: '#666' }}>Selected Works</h2>
            <div style={styles.grid}>
                {projects.map((p, i) => (
                    <div key={i} className="project-card" style={styles.card} id={p.category.toLowerCase() === 'music' ? 'music' : p.category.toLowerCase() === 'technology' ? 'tech' : undefined}>
                        <span style={{ display: 'block', marginBottom: '1rem', fontSize: '0.8rem', textTransform: 'uppercase', letterSpacing: '0.1em', color: '#888' }}>{p.category}</span>
                        <h3 style={{ marginBottom: '1rem', fontSize: '2.5rem', fontWeight: 400 }}>{p.title}</h3>
                        <p style={{ color: '#aaa', fontSize: '1.1rem', marginBottom: '2rem', maxWidth: '300px' }}>{p.desc}</p>
                        <a href={p.link} style={{ display: 'inline-block', marginTop: 'auto', borderBottom: '1px solid #fff', paddingBottom: '2px' }}>Explore</a>
                    </div>
                ))}
            </div>
        </section>
    );
}

const styles: Record<string, CSSProperties> = {
    grid: {
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
        gap: '2rem',
        borderTop: '1px solid #222',
    },
    card: {
        padding: '3rem 2rem',
        display: 'flex',
        flexDirection: 'column',
        transition: 'background 0.3s',
        borderRight: '1px solid #222',
        minHeight: '400px',
    }
};
