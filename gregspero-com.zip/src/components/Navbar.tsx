import Link from 'next/link';
import Image from 'next/image';
import { CSSProperties } from 'react';

export default function Navbar() {
    return (
        <nav className="glass" style={styles.nav}>
            <div className="container" style={styles.container}>
                <Link href="/" style={styles.logo}>
                    <span style={styles.logoText}>Greg Spero</span>
                </Link>
                <div style={styles.links}>
                    <Link href="#bio" style={styles.link}>Bio</Link>
                    <Link href="#music" style={styles.link}>Music</Link>
                    <Link href="#tech" style={styles.link}>Tech</Link>
                    <Link href="#contact" style={styles.link}>Contact</Link>
                </div>
            </div>
        </nav>
    );
}

const styles: Record<string, CSSProperties> = {
    nav: {
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100%',
        zIndex: 1000,
        padding: '1.5rem 0',
    },
    container: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    logo: {
        display: 'flex',
        alignItems: 'center',
    },
    logoImage: {
        height: '40px', // Fixed height for navbar
        width: 'auto',
        objectFit: 'contain',
    },
    logoText: {
        fontFamily: 'var(--font-heading)',
        fontSize: '1.25rem',
        fontWeight: 700,
        letterSpacing: '-0.02em',
        color: 'white',
        textTransform: 'uppercase',
        marginLeft: '0.75rem',
    },
    links: {
        display: 'flex',
        gap: '2rem',
    },
    link: {
        fontSize: '0.9rem',
        fontWeight: 500,
        color: 'var(--foreground)',
        opacity: 0.8,
        transition: 'opacity 0.2s',
    },
};
