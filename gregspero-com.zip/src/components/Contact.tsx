export default function Contact() {
    return (
        <section id="contact" className="section container" style={{ textAlign: 'center', paddingBottom: '10rem' }}>
            <h2 style={{ marginBottom: '2rem' }}>Get in Touch</h2>
            <p style={{ fontSize: '1.2rem', color: '#aaa', marginBottom: '3rem', maxWidth: '600px', margin: '0 auto 3rem' }}>
                For booking, collaboration, or press inquiries, please reach out via email.
            </p>
            <a href="mailto:info@gregspero.com" style={styles.button}>
                Say Hello
            </a>

            <div style={{ marginTop: '5rem', display: 'flex', justifyContent: 'center', gap: '2rem', flexWrap: 'wrap' }}>
                {['Instagram', 'YouTube', 'Spotify', 'Twitter'].map(social => (
                    <span key={social} style={{ color: '#666', cursor: 'pointer' }}>{social}</span>
                ))}
            </div>
        </section>
    );
}

const styles = {
    button: {
        background: 'white',
        color: 'black',
        padding: '1rem 3rem',
        borderRadius: '50px',
        fontWeight: 700,
        fontSize: '1.2rem',
        display: 'inline-block',
    }
};
