import { CSSProperties } from 'react';

export default function Hero() {
    return (
        <section style={styles.hero}>
            <video
                autoPlay
                muted
                loop
                playsInline
                style={styles.video}
                src="https://video.wixstatic.com/video/92ceff_ee4060aca62d461eac66459a35e9d944/1080p/mp4/file.mp4"
            />
            <div style={styles.overlay} />

            <div className="container" style={styles.content}>
                <div className="animate-fade-in">
                    <h1 style={styles.title}>
                        Greg Spero
                    </h1>
                    <div style={styles.separator} />
                    <p style={styles.subtitle}>
                        Visionary Pianist & Tech Entrepreneur
                    </p>
                </div>

                <div className="animate-fade-in" style={{ ...styles.actions, animationDelay: '0.3s' }}>
                    <a href="#music" className="glass" style={styles.primaryBtn}>
                        Experience
                    </a>
                </div>
            </div>
        </section>
    );
}

const styles: Record<string, CSSProperties> = {
    hero: {
        height: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        position: 'relative',
        overflow: 'hidden',
        marginTop: '-80px', // Pull under navbar
    },
    video: {
        position: 'absolute',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        objectFit: 'cover',
        zIndex: 0,
    },
    overlay: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: 'linear-gradient(to bottom, rgba(5,5,5,0.1) 0%, rgba(5,5,5,0.6) 100%)',
        zIndex: 1,
    },
    content: {
        textAlign: 'center',
        position: 'relative',
        zIndex: 2,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
    },
    title: {
        fontFamily: 'var(--font-heading)',
        fontSize: 'clamp(4rem, 10vw, 8rem)',
        fontWeight: 700,
        lineHeight: 1.1,
        marginBottom: '1rem',
        letterSpacing: '-0.02em',
        color: 'white',
        textTransform: 'uppercase',
    },
    separator: {
        width: '60px',
        height: '4px',
        background: 'var(--primary)',
        margin: '2rem auto',
        borderRadius: '2px',
    },
    subtitle: {
        fontSize: 'clamp(1rem, 2vw, 1.5rem)',
        color: '#e0e0e0',
        letterSpacing: '0.2rem',
        textTransform: 'uppercase',
        fontWeight: 300,
    },
    actions: {
        marginTop: '4rem',
    },
    primaryBtn: {
        padding: '1.2rem 3.5rem',
        color: 'white',
        borderRadius: '0',
        border: '1px solid rgba(255,255,255,0.3)',
        fontSize: '0.9rem',
        letterSpacing: '0.1em',
        textTransform: 'uppercase',
        transition: 'all 0.3s ease',
        background: 'rgba(255,255,255,0.05)',
        cursor: 'pointer',
    },
};
