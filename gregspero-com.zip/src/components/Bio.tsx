export default function Bio() {
    return (
        <section id="bio" className="section container">
            <div style={{ padding: '0 2rem' }}>
                <h2 style={{ marginBottom: '3rem', fontSize: '1rem', textTransform: 'uppercase', letterSpacing: '0.2em', color: '#666' }}>About</h2>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '4rem', fontSize: '1.25rem', lineHeight: '1.6', color: '#eee', fontWeight: 300 }}>
                    <div>
                        <p style={{ marginBottom: '2rem' }}>
                            Greg Spero is a pianist, composer, and entrepreneur bridging the gap between organic creative expression and modern technology.
                        </p>
                        <p>
                            He leads the jazz-fusion supergroup <strong>Spirit Fingers</strong> and has toured with <strong>Halsey</strong> and the <strong>Miles Electric Band</strong>.
                        </p>
                    </div>
                    <div>
                        <p style={{ marginBottom: '2rem' }}>
                            In the tech world, Greg is the founder of <strong>Artist AI</strong>, a platform capable of managing the logistical complexities of an artist's career, and <strong>The Recording Club</strong> (formerly Tiny Room), a hub for high-fidelity collaboration.
                        </p>
                        <p>
                            His work is unified by a single mission: to empower the human spirit through sound and innovation.
                        </p>
                    </div>
                </div>
            </div>
        </section>
    );
}
